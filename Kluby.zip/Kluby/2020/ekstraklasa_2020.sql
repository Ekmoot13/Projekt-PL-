INSERT INTO Kluby (Skrot, Nazwa) VALUES
('YKP', 'YKP Gdynia'),
('YCG', 'Yacht Club Gdańsk'),
('GIŻ', 'Giżycka Grupa Regatowa'),
('ISK', 'KS Iskra AMW Gdynia'),
('SZT', 'Sztorm Grupa'),
('POG', 'Pogoń Szczecin'),
('OKZ', 'Olsztyński Klub Żeglarski'),
('LEG', 'Legia Warszawa'),
('WOL', 'UKS Albatros Wolin'),
('77R', '77 Racing'),
('YCS', 'Yacht Club Sopot'),
('DZY', 'PŻKS Dżygit Białystok');
