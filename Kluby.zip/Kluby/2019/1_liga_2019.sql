INSERT INTO Kluby (Skrot, Nazwa) VALUES
('YCG', 'Yacht Club Gdańsk'),
('YKP', 'Yacht Klub Polski Gdynia'),
('WOL', 'UKS Albatros Wolin'),
('77R', '77 Racing Club'),
('AWF', 'AZS AWFiS Gdańsk'),
('JMZ', 'JK Między Żaglami'),
('JSG', 'Jachtklub Stoczni Gdańskiej'),
('POW', 'SKŻ Powidz'),
('LAS', 'RKS Lasery Zegrze');
