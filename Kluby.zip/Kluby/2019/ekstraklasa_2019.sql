INSERT INTO Kluby (Skrot, Nazwa) VALUES
('GIŻ', 'Giżycka Grupa Regatowa'),
('LEG', 'Legia Warszawa'),
('JEZ', 'Jeziorak Yacht Club'),
('IS2', 'KS Iskra AMW Gdynia'),
('OKZ', 'Olsztyński Klub Żeglarski'),
('SZT', 'Sztorm Grupa'),
('POG', 'SEJK Pogoń Szczecin'),
('DZY', 'PŻKS Dżygit Białystok'),
('JKM', 'JKM Gryf Gdynia'),
('ODY', 'Odyssey Sailing Club'),
('OD2', 'Odyssey Sailing Club 2'),
('YCS', 'Yacht Club Sopot');
