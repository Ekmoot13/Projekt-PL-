INSERT INTO Kluby (Skrot, Nazwa) VALUES
('MIC', 'Inex Green Micro Class'),
('POW', 'SKŻ Powidz'),
('HAL', 'KŻ Hals Gostynin'),
('YZ2', 'YKP Szczecin 2'),
('YKW', 'YKP Warszawa'),
('RBP', 'Regatta Business Poland'),
('SAT', 'Chotomowski KŻ Satchwell'),
('WTR', 'Warszawskie Towarzystwo Regatowe'),
('PJ2', 'Gandalf PPJK');
