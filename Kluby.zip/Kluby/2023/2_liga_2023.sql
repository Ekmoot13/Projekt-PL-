INSERT INTO Kluby (Skrot, Nazwa) VALUES
('ONB', 'Onboard'),
('MEC', 'Port Mechelinki'),
('BSA', 'BSA Flota Gdynia'),
('NSZ', 'Jachtklub Nowy Sztynort'),
('YKW', 'YKP Warszawa'),
('YZ2', 'YKP Szczecin 2'),
('SOL', 'KS Puchar Soliny'),
('RBP', 'Regatta Business Poland'),
('SRC', 'Symfonia Racing'),
('R2S', 'R2 Sailing Team'),
('HEA', 'Hear Studio Sailing Team'),
('AZS', 'AZS Poznań');
